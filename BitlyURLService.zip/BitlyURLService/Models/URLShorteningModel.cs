﻿using BitlyURLService.Utility;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using static BitlyURLService.ServiceDTO;

namespace BitlyURLService.Models
{
    public class URLShorteningModel
    {
        private string strURL = ConfigurationManager.AppSettings["ServiceURL"].ToString();
        private string strLoginId = ConfigurationManager.AppSettings["UserName"].ToString();
        private string strAPIKey = ConfigurationManager.AppSettings["ServiceKey"].ToString();
        private string strAccessToken = ConfigurationManager.AppSettings["AccessToken"].ToString();
        private string strBearerAccessToken = ConfigurationManager.AppSettings["BearerAccessToken"].ToString();

        /// <summary>
        /// This method is to Revert from LongUrl to TinyUrl
        /// </summary>
        public KeyValuePair<bool, string> GenerateGroupId()
        {
            bool _isSuccess = false;
            string message = string.Empty;
            string frameUrl = string.Empty;

            try
            {
                if (HttpContext.Current.Session["GUID"] != null)
                    return new KeyValuePair<bool, string>(false, "GroupId already exists.");

                frameUrl = strURL + "v4/groups";
                var response = BitlyService.Get(frameUrl, BitlyService.PostType.Json, strLoginId, strAccessToken);
                if (response.Any())
                {
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    RootGroup myDeserializedClass = serializer.Deserialize<RootGroup>(response);

                    foreach (Group group in myDeserializedClass.groups)
                    {
                        if (!string.IsNullOrEmpty(group.guid))
                        {
                            _isSuccess = true;
                            HttpContext.Current.Session["GUID"] = group.guid;
                            message = "New GroupId Created Succesfully!";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _isSuccess = false;
                message = "Failed to generate GroupId. Reason: " + ex.Message;
            }

            return new KeyValuePair<bool, string>(_isSuccess, message);
        }

        /// <summary>
        /// This method is used to get the no. of links saved in Bitly service
        /// </summary>
        /// <returns></returns>
        public KeyValuePair<bool, string> GetSavedURLs()
        {
            bool _isSuccess = false;
            string message = string.Empty;
            string frameUrl = string.Empty;
            List<UrlList> lst = new List<UrlList>();

            try
            {
                if (HttpContext.Current.Session["GUID"] == null)
                    return new KeyValuePair<bool, string>(false, "Please generate GroupId first to retive the list");

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                frameUrl = strURL + "v4/groups/" + HttpContext.Current.Session["GUID"].ToString() + "/bitlinks";
                var response = BitlyService.Get(frameUrl, BitlyService.PostType.Json, strLoginId, strBearerAccessToken);

                if (response.Any())
                {
                    SavedURLRoot myDeserializedClass = serializer.Deserialize<SavedURLRoot>(response);

                    foreach (LinksItem eItem in myDeserializedClass.links)
                    {
                        if (!string.IsNullOrEmpty(eItem.id))
                        {
                            lst.Add(new UrlList
                            {
                                Id = eItem.id,
                                CreatedOn = eItem.created_at,
                                ShortUrl = eItem.link,
                                LongUrl = eItem.long_url
                            });
                            _isSuccess = true;
                        }
                    }
                }
                message = serializer.Serialize(lst);
            }
            catch (Exception ex)
            {
                _isSuccess = false;
                message = "Failed to retrive saved URLs. Reason: " + ex.Message;
            }
            finally
            {
                lst = null;
            }

            return new KeyValuePair<bool, string>(_isSuccess, message);
        }

        public KeyValuePair<bool, string> NoOfClicksforURL(string url)
        {
            bool _isSuccess = false;
            string message = string.Empty;
            string frameUrl = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(url))
                    return new KeyValuePair<bool, string>(false, "Please provide valid input");

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                frameUrl = strURL + "v4/bitlinks/bit.ly/" + url.Substring(url.LastIndexOf('/') + 1) + "/clicks/summary";
                var response = BitlyService.Get(frameUrl, BitlyService.PostType.Json, strLoginId, strBearerAccessToken);

                if (response.Any())
                {
                    URLClicksCount myDeserializedClass = serializer.Deserialize<URLClicksCount>(response);
                    message = "Total No of Clicks: " + myDeserializedClass.total_clicks;
                    _isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                _isSuccess = false;
                message = "Failed to retrive no.of Clicks for URL. Reason: " + ex.Message;
            }

            return new KeyValuePair<bool, string>(_isSuccess, message);
        }

        /// <summary>
        /// This method is to Revert from LongUrl to ShortUrl
        /// </summary>
        public KeyValuePair<bool, string> ConvertLongUrlToShort(string longUrl)
        {
            bool _isSuccess = false;
            string message = string.Empty;
            string frameUrl = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(longUrl))
                    return new KeyValuePair<bool, string>(false, "Please provide valid input");

                if (HttpContext.Current.Session["GUID"] == null)
                    return new KeyValuePair<bool, string>(false, "Please generate GroupId first to do any action");

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                var jsonObj = new ShortenUrl { long_url = longUrl, group_guid = HttpContext.Current.Session["GUID"].ToString() };

                frameUrl = strURL + "v4/shorten";
                var response = BitlyService.Post(frameUrl, serializer.Serialize(jsonObj), BitlyService.PostType.Json, strLoginId, strBearerAccessToken);

                if (response.Any())
                {
                    ShortUrlToLong myDeserializedClass = serializer.Deserialize<ShortUrlToLong>(response);
                    message = "Generated Short URL: " + myDeserializedClass.link;
                    _isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                _isSuccess = false;
                message = "Failed to convert to Short URL. Reason: " + ex.Message;
            }

            return new KeyValuePair<bool, string>(_isSuccess, message);
        }

        /// <summary>
        /// This method is to Revert from shortURL to LongUrl
        /// </summary>
        public KeyValuePair<bool, string> ExpandShortenUrlToLong(string shortUrl)
        {
            bool _isSuccess = false;
            string message = string.Empty;
            string frameUrl = string.Empty;

            try
            {
                if (string.IsNullOrEmpty(shortUrl))
                    return new KeyValuePair<bool, string>(false, "Please provide valid input");

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                frameUrl = strURL + "v4/bitlinks/bit.ly/" + shortUrl.Substring(shortUrl.LastIndexOf('/') + 1);
                var response = BitlyService.Get(frameUrl, BitlyService.PostType.Json, strLoginId, strBearerAccessToken);

                if (response.Any())
                {
                    ShortUrlToLong myDeserializedClass = serializer.Deserialize<ShortUrlToLong>(response);
                    message = "Long URL: " + myDeserializedClass.long_url;
                    _isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                _isSuccess = false;
                message = "Failed to retrive Long URL. Reason: " + ex.Message;
            }

            return new KeyValuePair<bool, string>(_isSuccess, message);
        }
    }
}