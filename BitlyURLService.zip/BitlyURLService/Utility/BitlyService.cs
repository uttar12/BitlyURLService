﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace BitlyURLService.Utility
{
    public static class BitlyService
    {
        public enum PostType
        {
            Json,
            Xml,
            FormData,
            Others
        }
        private static void SetBearerAuthHeader(WebRequest request, string token)
        {
            if (token == "")
                return;
            request.Headers["Authorization"] = token;
        }

        public static string Post(string url,string jsonObject, PostType postType, string username, string bearerAuth = "")
        {
            try
            {
                byte[] bytes;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                SetBearerAuthHeader(request, bearerAuth);

                bytes = Encoding.UTF8.GetBytes(jsonObject);
                switch (postType)
                {
                    case PostType.Json:
                        request.ContentType = "application/json";
                        break;
                    case PostType.Xml:
                        request.ContentType = "application/xml; encoding='utf-8'";
                        break;
                    case PostType.FormData:
                        request.ContentType = "application/form-data; encoding='utf-8'";
                        break;
                }
                //request.ContentLength = bytes.Length;
                request.Method = "POST";
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();

                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK
                    || response.StatusCode == HttpStatusCode.Created
                    || response.StatusCode == HttpStatusCode.BadRequest)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();
                    return responseStr;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }
        public static string Get(string url, PostType postType, string username, string bearerAuth = "")
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            SetBearerAuthHeader(request, bearerAuth);

            switch (postType)
            {
                case PostType.Json:
                    request.ContentType = "application/json";
                    break;
                case PostType.Xml:
                    request.ContentType = "application/xml; encoding='utf-8'";
                    break;
                case PostType.FormData:
                    request.ContentType = "application/form-data; encoding='utf-8'";
                    break;
            }

            request.Method = "GET";

            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK
                || response.StatusCode == HttpStatusCode.Created
                || response.StatusCode == HttpStatusCode.BadRequest)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();
                return responseStr;
            }
            return null;
        }
    }
}