﻿$(function () {
    (function blink() {
        $('.blink_me').fadeOut(500).fadeIn(1000, blink);
    })();

    $('#divMessage').hide();
    $('#spnMessage').html('');
    $('.linkGroups').hide();

    $('#btnGetGUID, #btnGetAccessToken, #btnGetBitlinksbyGroup, #btnClicksClear, #btnExpandClear, #btnShorternClear, #lnkClear').click(function () {
        $('#txtShorternURL').val('');
        $('#txtExpandURL').val('');
        $('#txtClicks').val('');
        $('#txtUserShorternUrl').val('');
        $('#txtCheckIfExist').val('');
        $('#txtClicksShorternUrl').val('');
        $('#divMessage').hide();
        $('.linkGroups').hide();
        $('#maintable').html('');
    });

    $('body').on('click', '.btn-checkbox', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var $radio = $(this).find(':input[type=radio]');
        if ($radio.length) {
            var $group = $radio.closest('.btn-group');
            $group.find(':input[type=radio]').not($radio).each(function () {
                unchecked($(this));
            });
            var $icon = $(this).find('[data-icon-on]');
            if ($radio.is(':checked')) {
                unchecked($radio);
            } else {
                checked($radio);
                DivShowHide($(this).find('input[type=radio]').val());
            }
            return;
        }
    });

    $('#lnkClear').click(function () {
        $('#spnMessage').html('');
        $('.linkGroups').hide();
        $('#maintable').html('');
        $('#txtShorternURL').val('');
        $('#txtExpandURL').val('');
        $('#txtClicks').val('');
        $('#txtUserShorternUrl').val('');
        $('#txtCheckIfExist').val('');
        $('#txtClicksShorternUrl').val('');
        $('#divMessage').hide();

        $('.divActions').each(function (i, obj) {
            $(this).addClass('cssHidden');
        });
        return false;
    });

    $('#lnkClearGuid').click(function () {
        AjaxGet('/URLShortening/ClearGeneratedGroupId/');
        return false;
    });

    $('#btnGetGUID').click(function () {
        AjaxGet('/URLShortening/GenerateGroupId/');
        return false;
    });

    $('#btnGetBitlinksbyGroup').click(function () {
        AjaxGetDataTable('/URLShortening/GetSavedURLs/');
        return false;
    });

    $('#btnClicks').click(function () {
        var isValid = Validation('txtClicksShorternUrl');

        if (isValid) {
            var data = {
                url: $('#txtClicksShorternUrl').val().trim()
            };

            AjaxPost('/URLShortening/NoOfClicksforURL/', data);
        }
        return false;
    });

    $('#btnExpandSubmit').click(function () {
        var isValid = Validation('txtExpandURL');

        if (isValid) {
            var data = {
                url: $('#txtExpandURL').val().trim()
            };

            AjaxPost('/URLShortening/ExpandShortenUrlToLong/', data);
        }
        return false;
    });

    $('#btnShorternSubmit').click(function () {
        var isValid = Validation('txtShorternURL');

        if (isValid) {
            var data = {
                url: $('#txtShorternURL').val().trim()
            };

            AjaxPost('/URLShortening/ConvertLongUrlToShort/', data);
        }
        return false;
    });

    function Validation(ctrlId) {
        var isValid = true;
        if ($('#' + ctrlId).val() == null || $('#' + ctrlId).val().length == 0) {
            $('#divMessage').show();
            $('#divMessage').removeClass('success');
            $('#divMessage').addClass('error');
            $('#spnMessage').html('Please enter a valid URL!');
            isValid = false;
        } else {
            var isValidUrl = isUrlValid($('#' + ctrlId).val().trim());
            if (!isValidUrl) {
                $('#divMessage').show();
                $('#divMessage').removeClass('success');
                $('#divMessage').addClass('error');
                $('#spnMessage').html('Invalid URL!');
                isValid = false;
            }
        }
        return isValid;
    }

    function isUrlValid(userInput) {
        var regexp = /(https?|ftp):\/\/[^\s\/$.?#].[^\s]*/i;
        console.log('Test: ' + regexp.test(userInput));
        if (regexp.test(userInput))
            return true;
        else
            return false;
    }

    function checked($input) {
        var $button = $input.closest('.btn');
        var $icon = $button.find('[data-icon-on]');
        $button.addClass('active');
        $input.prop('checked', true);
        $icon.css('width', $icon.width());
        $icon.removeAttr('class').addClass($icon.data('icon-on'));
        $input.trigger('change');
    }

    function unchecked($input) {
        var $button = $input.closest('.btn');
        var $icon = $button.find('[data-icon-on]');
        $button.removeClass('active');
        $input.prop('checked', false);
        $icon.css('width', $icon.width());
        $icon.removeAttr('class').addClass($icon.data('icon-off'));
        $input.trigger('change');
    }

    function DivShowHide(divName) {
        $('.divActions').each(function (i, obj) {
            if ($(this).attr('id') === divName) {
                $(this).removeClass('cssHidden');
            }
            else {
                if (!$(this).hasClass('cssHidden'))
                    $(this).addClass('cssHidden');
            }
        });
    }

    function AjaxGetDataTable(Url) {
        $.ajax({
            type: 'GET',
            url: Url,
            contentType: "application/json; charset=utf-8",
            cache: false,
            processData: false,
            success: function (data) {
                var results = data;
                if (results.Key) {
                    $('#divMessage').removeClass('error');
                    $('#divMessage').addClass('success');
                    $('.linkGroups').show();

                    $('#maintable').DataTable({
                        "data": $.parseJSON(results.Value),
                        "bProcessing": true,
                        "bSearchable": true,
                        "bDestroy": true,
                        "order": [[1, 'asc']],
                        "columns": [
                            { "data": "Id", title: "Id" },
                            { "data": "CreatedOn", title: "Created On" },
                            { "data": "ShortUrl", title: "Short Url" },
                            { "data": "LongUrl", title: "Long Url" }
                        ]
                    });
                }
                else {
                    $('#divMessage').removeClass('success');
                    $('#divMessage').addClass('error');
                    $('#spnMessage').html(results.Value);
                    $('#divMessage').show();
                }
            },
            error: function (data) {
                $('#divMessage').show();
                $('#divMessage').removeClass('success');
                $('#divMessage').addClass('error');
                $('#spnMessage').html('An error occurre!');
                console.log(data);
            }
        });
    }

    function AjaxGet(Url) {
        $.ajax({
            type: 'GET',
            url: Url,
            contentType: "application/json; charset=utf-8",
            cache: false,
            processData: false,
            success: function (data) {
                var results = data;
                if (results.Key) {
                    $('#divMessage').removeClass('error');
                    $('#divMessage').addClass('success');
                }
                else {
                    $('#divMessage').removeClass('success');
                    $('#divMessage').addClass('error');
                }

                $('#spnMessage').html(results.Value);
                $('#divMessage').show();
            },
            error: function (data) {
                $('#divMessage').show();
                $('#divMessage').removeClass('success');
                $('#divMessage').addClass('error');
                $('#spnMessage').html('An error occurre!');
                console.log(data);
            }
        });
    }

    function AjaxPost(Url, data) {
        $.ajax({
            type: 'POST',
            url: Url,
            data: JSON.stringify(data),
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            cache: false,
            processData: false,
            success: function (data) {
                var results = data;
                if (results.Key) {
                    $('#divMessage').removeClass('error');
                    $('#divMessage').addClass('success');
                }
                else {
                    $('#divMessage').removeClass('success');
                    $('#divMessage').addClass('error');
                }

                $('#spnMessage').html(results.Value);
                $('#divMessage').show();
            },
            error: function (data) {
                $('#divMessage').show();
                $('#divMessage').removeClass('success');
                $('#divMessage').addClass('error');
                $('#spnMessage').html('An error occurre!');
                console.log(data);
            }
        });
    }
});