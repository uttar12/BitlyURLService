﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitlyURLService
{
    public class ServiceDTO
    {
        #region Generate GroupId
        public class References
        {
            public string organization { get; set; }
        }
        public class Group
        {
            public DateTime created { get; set; }
            public DateTime modified { get; set; }
            public List<object> bsds { get; set; }
            public string guid { get; set; }
            public string organization_guid { get; set; }
            public string name { get; set; }
            public bool is_active { get; set; }
            public string role { get; set; }
            public References references { get; set; }
        }

        public class RootGroup
        {
            public List<Group> groups { get; set; }
        }
        #endregion
    }

    public class UrlList
    {
        public string Id { get; set; }
        public string CreatedOn { get; set; }
        public string ShortUrl { get; set; }
        public string LongUrl { get; set; }
    }

    #region Get Saved Urls List

    public class References
    {
        public string group { get; set; }
    }

    public class LinksItem
    {
        public string created_at { get; set; }
        public string id { get; set; }
        public string link { get; set; }
        public List<string> custom_bitlinks { get; set; }
        public string long_url { get; set; }
        public string archived { get; set; }
        public string created_by { get; set; }
        public string client_id { get; set; }
        public List<string> tags { get; set; }
        public List<string> deeplinks { get; set; }
        public References references { get; set; }
    }

    public class Pagination
    {
        public string prev { get; set; }
        public string next { get; set; }
        public int size { get; set; }
        public int page { get; set; }
        public int total { get; set; }
    }

    public class SavedURLRoot
    {
        public List<LinksItem> links { get; set; }
        public Pagination pagination { get; set; }
    }

    #endregion

    public class URLClicksCount
    {
        public string unit_reference { get; set; }
        public string total_clicks { get; set; }
        public string units { get; set; }
        public string unit { get; set; }
    }


    public class ShortenUrl
    {
        public string long_url { get; set; }
        public string group_guid { get; set; }
    }

    #region Convert / Get ShortUrlToLong

    public class ShortUrlToLong
    {
        public DateTime created_at { get; set; }
        public string id { get; set; }
        public string link { get; set; }
        public List<object> custom_bitlinks { get; set; }
        public string long_url { get; set; }
        public bool archived { get; set; }
        public string created_by { get; set; }
        public string client_id { get; set; }
        public List<object> tags { get; set; }
        public List<object> deeplinks { get; set; }
        public References references { get; set; }
    }

    #endregion

}