﻿using BitlyURLService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BitlyURLService.Controllers
{
    public class URLShorteningController : Controller
    {
        // GET: URLShortening
        public ActionResult Index()
        {
            URLShorteningModel obj = new URLShorteningModel();
            return View();
        }

        [HttpGet]
        [ActionName("ClearGeneratedGroupId")]
        public JsonResult RemoveUniqueGroupId()
        {
            if (HttpContext.Session["GUID"] != null)
                HttpContext.Session["GUID"] = null;

            var response = new KeyValuePair<bool, string>(true, "Deleted GroupId successfully!!!");
            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        [ActionName("GenerateGroupId")]
        public JsonResult GenerateUniqueGroupId()
        {
            var response = new KeyValuePair<bool, string>();
            var obj = new URLShorteningModel();
            response = obj.GenerateGroupId();

            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        [ActionName("GetSavedURLs")]
        public JsonResult RetrieveBitlinksbyGroup()
        {
            KeyValuePair<bool, string> response = new KeyValuePair<bool, string>();

            var obj = new URLShorteningModel();
            response = obj.GetSavedURLs();
            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ActionName("NoOfClicksforURL")]
        public JsonResult GetURLClicksCount(string url)
        {
            KeyValuePair<bool, string> response = new KeyValuePair<bool, string>();

            var obj = new URLShorteningModel();
            response = obj.NoOfClicksforURL(url);
            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ActionName("ExpandShortenUrlToLong")]
        public JsonResult GetLongUrlfromShortUrl(string url)
        {
            KeyValuePair<bool, string> response = new KeyValuePair<bool, string>();

            var obj = new URLShorteningModel();
            response = obj.ExpandShortenUrlToLong(url);
            return Json(response, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ActionName("ConvertLongUrlToShort")]
        public JsonResult GenerateShortUrlfromLongUrl(string url)
        {
            KeyValuePair<bool, string> response = new KeyValuePair<bool, string>();

            var obj = new URLShorteningModel();
            response = obj.ConvertLongUrlToShort(url);
            return Json(response, JsonRequestBehavior.AllowGet);
        }
    }
}